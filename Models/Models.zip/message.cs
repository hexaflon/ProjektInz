﻿namespace TestTest.Models
{
    public class message
    {
        public string tresc { get; set; }
        public message(string tresc)
        {
            this.tresc = tresc;
        }
    }
}
