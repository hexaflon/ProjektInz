﻿namespace TestTest.Models
{
    public class LoginByUsernamePassword
    {
    }
}
