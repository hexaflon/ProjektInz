﻿using System;
using System.Collections.Generic;

namespace TestTest.Models.Db
{
    public partial class User
    {
        public User()
        {
            Tests = new HashSet<Test>();
        }

        public int Id { get; set; }
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string? Name { get; set; }

        public virtual ICollection<Test> Tests { get; set; }
    }
}
